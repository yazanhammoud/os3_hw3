#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <stdlib.h>
#include <string.h>
#include "message_slot.h"

int main(int argc, char *argv[]) {
    int fd;
    unsigned int channel_id;
    size_t msg_len;
    int ret;

    if (argc != 4) {
        fprintf(stderr, "Usage: %s <file_path> <channel_id> <message>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    channel_id = (unsigned int)atoi(argv[2]);
    if (channel_id == 0 ) {
        fprintf(stderr, "Invalid channel ID. Must be greater than 0.\n");
        exit(EXIT_FAILURE);
    }

    msg_len = strlen(argv[3]);
    if (msg_len == 0 || msg_len > MAX_MESSAGE_SIZE) {
        fprintf(stderr, "Invalid message length. Must be between 1 and %d bytes.\n", MAX_MESSAGE_SIZE);
        exit(EXIT_FAILURE);
    }

    fd = open(argv[1], O_WRONLY);
    if (fd < 0) {
        perror("open");
        exit(EXIT_FAILURE);
    }

    ret = ioctl(fd, MSG_SLOT_CHANNEL, &channel_id);
    if (ret < 0) {
        perror("ioctl");
        close(fd);
        exit(EXIT_FAILURE);
    }

    ret = write(fd, argv[3], msg_len);
    if (ret < 0) {
        perror("write");
        close(fd);
        exit(EXIT_FAILURE);
    }

    close(fd);
    return 0;
}