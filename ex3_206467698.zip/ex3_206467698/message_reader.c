#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <stdlib.h>
#include "message_slot.h"

int main(int argc, char *argv[]) {
    int fd;
    unsigned int channel_id;
    char buffer[128];
    ssize_t bytes_read;

    if (argc != 3) {
        fprintf(stderr, "Usage: %s <file_path> <channel_id>\n", argv[0]);
        return EXIT_FAILURE;
    }

    channel_id = (unsigned int)atoi(argv[2]);
    if (channel_id == 0 ) {
        fprintf(stderr, "Invalid channel ID. Must be greater than 0.\n");
        return EXIT_FAILURE;
    }

    fd = open(argv[1], O_RDONLY);
    if (fd < 0) {
        perror("open");
        return EXIT_FAILURE;
    }

    if (ioctl(fd, MSG_SLOT_CHANNEL, &channel_id) < 0) {
        perror("ioctl");
        close(fd);
        return EXIT_FAILURE;
    }

    bytes_read = read(fd, buffer, sizeof(buffer) - 1);
    if (bytes_read < 0) {
        perror("read");
        close(fd);
        return EXIT_FAILURE;
    }

    buffer[bytes_read] = '\0';
    printf( "%s\n", buffer);

    close(fd);
    return EXIT_SUCCESS;
}